/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg4qa_enrolmentsystem_nogueraszach_python;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author zacha
 */
public class UserData implements Serializable {
    private String username;
    private String password;
    private List<String> enrolledSubjects; // List to store enrolled subjects

    public UserData(String username, String password) {
        this.username = username;
        this.password = password;
        this.enrolledSubjects = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Method to add enrolled subject
    public void addEnrolledSubject(String subject) {
        enrolledSubjects.add(subject);
    }

    // Method to get enrolled subjects
    public List<String> getEnrolledSubjects() {
        return enrolledSubjects;
    }
}
